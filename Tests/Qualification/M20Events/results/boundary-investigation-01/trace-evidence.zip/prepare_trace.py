from pathlib import Path
import re,shlex,subprocess,json,hashlib
repo=Path.cwd();out=repo/'build/m20-boundary-investigation-2026-11-20';build=repo/'build/m20-events-2026-11-19/compile'
header=(repo/'Source/Core/Proposal/EventPlanning.h').read_text();start=header.index('class EventFeatureCollector');end=header.index('enum class EventCoverageClass',start)
(out/'DiagnosticEventFeatures.h').write_text('#pragma once\n#include "Core/Proposal/EventPlanning.h"\n#include <ostream>\nnamespace levelscope::proposal {\nextern std::ostream* eventTraceStream;\n'+header[start:end].replace('EventFeatureCollector','DiagnosticEventFeatureCollector')+'}\n')
src=(repo/'Source/Core/Proposal/EventFeatures.cpp').read_text();start=src.index('size_t EventEvidence::storageBytes()');end=src.index('struct EventFeatureCollector::Impl',start);src=src[:start]+src[end:]
src=src.replace('#include "EventPlanning.h"','#include "DiagnosticEventFeatures.h"').replace('EventFeatureCollector','DiagnosticEventFeatureCollector')
needle='            const bool attack=(f||l)&&!s.latched;'
assert src.count(needle)==1
logging='''
            if(eventTraceStream && position<=int64_t(data->sampleRate)*66 && root.hint.begin<int64_t(data->sampleRate)*65)
            {
                const EventGroup* active=s.active?&data->groups[*s.active]:nullptr;
                *eventTraceStream << position << ',' << r << ',' << fast << ',' << low << ',' << f << ',' << l << ',' << dual << ',' << sustained << ',' << corroborated << ',' << attack << ',' << s.latched << ',' << s.fastStart << ',' << s.lowStart << ',' << (active?int64_t(*s.active):-1) << ',' << (active?active->onset.begin:-1) << ',' << (active?active->onset.end:-1) << ',' << (active?active->lastAttack.end:-1) << ',' << (active?active->corroborated:false) << ',' << s.quietStart << ',' << s.decayStart << ',' << feature.fast[0] << ',' << feature.fast[1] << ',' << feature.low[0] << ',' << feature.low[1] << ',' << bg[0] << ',' << bg[1] << ',' << bgLow[0] << ',' << bgLow[1] << ',' << s.background[0] << ',' << s.background[1] << ',' << s.lowBackground[0] << ',' << s.lowBackground[1] << ',' << accumulating.peak << ',' << accumulating.peakFrame << ',' << cell.fastContrast << ',' << cell.lowContrast << '\\n';
            }
'''
src=src.replace(needle,needle+logging);(out/'DiagnosticEventFeatures.cpp').write_text(src)
flags=(build/'CMakeFiles/LevelScopeEventPlanningTests.dir/flags.make').read_text();args=[]
for name in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']:
 args+=shlex.split(re.search(r'^'+name+r' = (.*)$',flags,re.M)[1])
args=[x.replace('\\"','"') for x in args]
# Diagnostic only, native execution. Frozen universal targets are not rebuilt.
for i in range(len(args)-2,-1,-1):
 if args[i:i+2]==['-arch','x86_64']:del args[i:i+2]
args+=['-I'+str(repo/'Tests'),'-I'+str(out)]
commands=[]
for source in ['DiagnosticEventFeatures.cpp','trace.cpp']:
 cmd=['/usr/bin/c++',*args,'-c',str(out/source),'-o',str(out/(source+'.o'))];commands.append(cmd);subprocess.run(cmd,check=True)
link=shlex.split((build/'CMakeFiles/LevelScopeEventPlanningTests.dir/link.txt').read_text());link[link.index('CMakeFiles/LevelScopeEventPlanningTests.dir/Tests/EventPlanningTests.cpp.o')]=str(out/'trace.cpp.o');link.insert(1,str(out/'DiagnosticEventFeatures.cpp.o'));link[link.index('-o')+1]=str(out/'m20-boundary-trace')
for i in range(len(link)-2,-1,-1):
 if link[i:i+2]==['-arch','x86_64']:del link[i:i+2]
commands.append(link);subprocess.run(link,cwd=build,check=True)
(out/'compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
